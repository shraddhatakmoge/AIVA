import os
import time
import pyautogui
import pygetwindow as gw
import pyperclip
import pyttsx3
import threading



pyautogui.FAILSAFE = False

last_message = ""
engine = pyttsx3.init()
STOP_RECORDING = False  #

def speak(text):
    print("🔊", text)
    engine.say(text)
    engine.runAndWait()



# -------- OPEN --------
def open_whatsapp():
    print("🚀 JARVIS: Attempting to launch WhatsApp...")
    
    # 1. Build the dynamic paths where the .exe is typically installed
    local_appdata = os.environ.get("LOCALAPPDATA", "")
    program_files = os.environ.get("PROGRAMFILES", "")
    
    exe_path_local = os.path.join(local_appdata, "WhatsApp", "WhatsApp.exe")
    exe_path_prog = os.path.join(program_files, "WhatsApp", "WhatsApp.exe")
    
    # 2. Check for the .exe version first
    if os.path.exists(exe_path_local):
        os.startfile(exe_path_local)
        
    elif os.path.exists(exe_path_prog):
        os.startfile(exe_path_prog)
        
    else:
        # 3. Fallback to your original Microsoft Store App version
        os.system("start shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App")
        
    time.sleep(3)


# -------- CLOSE --------
def close_whatsapp():


    # Try process kill
    os.system("taskkill /f /im WhatsApp.exe >nul 2>&1")

    # Fallback: close by window title
    os.system('taskkill /f /fi "WINDOWTITLE eq WhatsApp*" >nul 2>&1')

    print("✅ WhatsApp closed")

# -------- FOCUS --------
def focus_whatsapp():
    windows = gw.getWindowsWithTitle("WhatsApp")

    for win in windows:
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
            time.sleep(1)
            return True
        except:
            continue

    open_whatsapp()
    return False


# -------- SEND --------
def send_message(text):
    global last_message

    focus_whatsapp()
    time.sleep(1)

    pyautogui.write(text, interval=0.05)
    pyautogui.press("enter")

    last_message = text
    print("📤 Sent:", text)


# -------- SEND TO CONTACT --------
def send_message_to(contact, text):
    global last_message

    focus_whatsapp()
    time.sleep(2)

    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)

    pyautogui.write(contact)
    time.sleep(2)

    pyautogui.press("down")
    pyautogui.press("enter")
    time.sleep(1)

    pyautogui.write(text)
    pyautogui.press("enter")

    last_message = text
    print(f"📤 Sent to {contact}: {text}")


# =========================================
# 🚀 NEW FEATURES START HERE
# =========================================


# -------- SEND SCREENSHOT --------
import os
import time
import io
from PIL import Image
import win32clipboard
import pyautogui

def get_latest_screenshot(folder):
    files = [os.path.join(folder, f) for f in os.listdir(folder)
             if f.lower().endswith((".png", ".jpg", ".jpeg"))]

    if not files:
        return None

    latest_file = max(files, key=os.path.getctime)
    return latest_file


def send_screenshot(contact):
    focus_whatsapp()
    time.sleep(1)

    # 🔥 DYNAMIC PATH FIX: Automatically finds the Screenshots folder for ANY user
    user_profile = os.path.expanduser('~')
    onedrive_path = os.path.join(user_profile, "OneDrive", "Pictures", "Screenshots")
    local_path = os.path.join(user_profile, "Pictures", "Screenshots")
    
    # Check if their laptop uses OneDrive or Local storage
    folder = onedrive_path if os.path.exists(onedrive_path) else local_path

    path = get_latest_screenshot(folder)

    if not path:
        print("❌ No screenshot found")
        speak("No screenshot found")
        return

    print("📸 Sending:", path)

    # 🔥 Step 2: Load image
    img = Image.open(path)

    # 🔥 Step 3: Copy to clipboard
    output = io.BytesIO()
    img.convert("RGB").save(output, "BMP")
    data = output.getvalue()[14:]
    output.close()

    win32clipboard.OpenClipboard()
    win32clipboard.EmptyClipboard()
    win32clipboard.SetClipboardData(win32clipboard.CF_DIB, data)
    win32clipboard.CloseClipboard()

    # 🔥 Step 4: Open chat
    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)

    pyautogui.write(contact)
    time.sleep(2)

    pyautogui.press("down")
    pyautogui.press("enter")
    time.sleep(1)

    # 🔥 Step 5: Paste image
    pyautogui.hotkey("ctrl", "v")
    time.sleep(1)

    pyautogui.press("enter")

    print("✅ Latest screenshot sent")

# --------- VOICE CALL ---------
def voice_call(contact):
    focus_whatsapp()
    time.sleep(1)

    # 🔥 Close anything
    for _ in range(2):
        pyautogui.press("esc")
        time.sleep(0.3)

    # 🔍 Open search
    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)

    # 🔥 CLEAR SEARCH (IMPORTANT)
    pyautogui.hotkey("ctrl", "a")
    time.sleep(0.2)
    pyautogui.press("backspace")
    time.sleep(0.3)

    # 🔥 Type contact
    pyautogui.write(contact, interval=0.05)
    time.sleep(2)

    pyautogui.press("enter")
    time.sleep(2)

    for _ in range(9):
        pyautogui.press("tab")
        time.sleep(0.2)

    pyautogui.press("enter")

    for _ in range(7):
        pyautogui.press("tab")
        time.sleep(0.2)

    pyautogui.press("enter")
    


    print("🎥 Video calling", contact)

# ------ VIDEO CALL -------    
def video_call(contact):
    focus_whatsapp()
    time.sleep(1)

    # 🔥 Close anything
    for _ in range(2):
        pyautogui.press("esc")
        time.sleep(0.3)

    # 🔍 Open search
    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)

    # 🔥 CLEAR SEARCH (IMPORTANT)
    pyautogui.hotkey("ctrl", "a")
    time.sleep(0.2)
    pyautogui.press("backspace")
    time.sleep(0.3)

    # 🔥 Type contact
    pyautogui.write(contact, interval=0.05)
    time.sleep(2)

    pyautogui.press("enter")
    time.sleep(2)

    for _ in range(9):
        pyautogui.press("tab")
        time.sleep(0.2)

    pyautogui.press("enter")

    for _ in range(6):
        pyautogui.press("tab")
        time.sleep(0.2)

    pyautogui.press("enter")
    
    print("🎥 Video calling", contact)
    
# ----- MUTE/UNMUTE CALL ------------   
def mute_call():
    print("🔇 Muting system microphone...")
    time.sleep(1)

    pyautogui.hotkey("win", "alt", "k")

    print("✅ Mic muted")


def unmute_call():
    print("🔊 Unmuting system microphone...")
    time.sleep(1)

    pyautogui.hotkey("win", "alt", "k")

    print("✅ Mic unmuted")
        
# ---------- CHECK STATUS ---------      
def open_status_by_click(contact):

    open_whatsapp()
    time.sleep(2)

    # 🔥 Step 1: CLOSE anything (search/chat)
    for _ in range(2):
        pyautogui.press("esc")
        time.sleep(0.3)

    # 🔥 Step 2: Open search
    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)

    # 🔥 Step 3: CLEAR OLD TEXT
    pyautogui.hotkey("ctrl", "a")   # select all
    time.sleep(0.3)
    pyautogui.press("backspace")    # delete
    time.sleep(0.3)

    # 🔥 Step 4: TYPE CONTACT
    pyautogui.write(contact)
    time.sleep(2)

    # 🔥 Step 5: CLICK YOUR COORDINATES
    pyautogui.moveTo(157, 445)  # 👈 replace with your coords
    time.sleep(0.5)
    pyautogui.click()

    print("👁️ Status opened")
    

# -------- VOICE MESSAGE -----------
def send_voice_message(contact):
    open_whatsapp()
    # No need for threads anymore! It runs, locks the mic, and finishes.
    _record_voice(contact)

def _record_voice(contact):
    focus_whatsapp()
    time.sleep(1)

    for _ in range(2):
        pyautogui.press("esc")
        time.sleep(0.3)

    pyautogui.hotkey("ctrl", "alt", "/")
    time.sleep(1)

    pyautogui.hotkey("ctrl", "a")
    pyautogui.press("backspace")

    pyautogui.write(contact, interval=0.05)
    time.sleep(2)

    pyautogui.press("enter")
    time.sleep(2)

    print(f"➡️ Chat opened for {contact}")

    # 🎤 Move to Mic
    pyautogui.moveTo(1848, 955)
    time.sleep(0.5)

    # 🔥 THE FIX: Swipe UP to lock the mic
    pyautogui.mouseDown()
    time.sleep(0.5)
    pyautogui.moveRel(0, -100, duration=0.5) # Drags the mouse up 100 pixels
    pyautogui.mouseUp()                      # Releases the mouse. Mic is now locked!

    print("🎙️ Recording Locked... (Type 'stop recording' when ready to send)")

    
def stop_voice_message():
    # 🔥 Bring WhatsApp to front
    focus_whatsapp()
    time.sleep(1)

    # 🎯 Move back to the exact same coordinates (which is now the SEND button)
    pyautogui.moveTo(1848, 955)  
    time.sleep(0.3)

    # 🔥 Click to send
    pyautogui.click()

    print("✅ Voice message sent")
    
# -------- SEND ATTACHMENT (DOCUMENT/FILE) --------
def send_attachment(contact, filename, search_location=None):
    """
    Portable version: Uses keyboard shortcuts and dynamic pathing.
    No hardcoded coordinates or user-specific paths.
    """
    # --- STEP 1: DYNAMIC PATH RESOLUTION ---
    user_home = os.path.expanduser("~")
    
    # Map spoken locations to actual system paths
    location_map = {
        "desktop": os.path.join(user_home, "Desktop"),
        "downloads": os.path.join(user_home, "Downloads"),
        "documents": os.path.join(user_home, "Documents")
    }
    
    file_path = None
    
    # If you specified a location (e.g., "from desktop")
    if search_location and search_location.lower() in location_map:
        file_path = os.path.join(location_map[search_location.lower()], filename)
    else:
        # Otherwise, search all common folders automatically
        for folder in location_map.values():
            temp_path = os.path.join(folder, filename)
            if os.path.exists(temp_path):
                file_path = temp_path
                break

    if not file_path or not os.path.exists(file_path):
        print(f"❌ JARVIS: Could not find '{filename}' in common folders.")
        return

    # --- STEP 2: PORTABLE UI NAVIGATION ---
    focus_whatsapp()
    time.sleep(1)

    # Universal Search shortcut
    pyautogui.hotkey("ctrl", "f")
    time.sleep(0.5)
    pyautogui.hotkey("ctrl", "a")   # select all
    time.sleep(0.3)
    pyautogui.press("backspace")    # delete
    time.sleep(0.3)
    pyautogui.write(contact)
    time.sleep(1.5)
    pyautogui.press("enter")
    time.sleep(1)

    print(f"📎 JARVIS: Attaching {filename}...")
    
    # Navigation: From the message box, Shift+Tab usually hits the '+' button
    pyautogui.hotkey("shift", "tab")
    pyautogui.hotkey("shift", "tab")

    time.sleep(0.3)
    pyautogui.press("enter") # Opens the attachment menu
    time.sleep(1)

    # Select 'Document' (First item in menu)
    pyautogui.press("enter") 
    time.sleep(2)

    # Standard Windows File Dialog (This is universal)
    pyautogui.write(file_path)
    time.sleep(0.5)
    pyautogui.press("enter")
    
    # ==========================================
    # 🔥 THE FIX STARTS HERE
    # ==========================================
    
    # 1. Wait longer for the Preview screen to appear
    print("⏳ JARVIS: Waiting for file preview...")
    time.sleep(4) 
    
    # 2. RE-FOCUS WHATSAPP (Crucial: The Dialog closure steals focus!)
    focus_whatsapp() 
    time.sleep(0.5)

    # 3. Press TAB once
    # This moves focus from the 'Add a caption' box to the actual 'Send' button
    pyautogui.press("tab")
    time.sleep(0.3)

    # 4. Final Send
    pyautogui.press("enter")
    
    print(f"✅ JARVIS: Document '{filename}' sent to {contact}")
   
   
# -------- SEND CONTACT CARD --------
def send_contact_card(target_person, contact_to_share):
    """
    Portable version: Uses keyboard navigation instead of coordinates 
    to ensure it works on any screen resolution.
    """
    # 1. Bring WhatsApp to focus & open the target's chat
    focus_whatsapp()
    time.sleep(1)

    pyautogui.hotkey("ctrl", "f")
    time.sleep(1)
    pyautogui.hotkey("ctrl", "a")
    pyautogui.press("backspace")
    pyautogui.write(target_person)
    time.sleep(2)
    pyautogui.press("down")
    pyautogui.press("enter")
    time.sleep(1.5)

    # 2. Open Attachment Menu using keyboard
    # From the message box, Shift+Tab twice usually lands on the '+' button
    pyautogui.hotkey("shift", "tab")
    pyautogui.hotkey("shift", "tab")
    time.sleep(0.5)
    pyautogui.press("enter") 
    time.sleep(1.5)

    # 3. Navigate to "Contact" in the menu
    # Usually, 'Contact' is the 4th item down in the attachment menu
    for _ in range(4):
        pyautogui.press("down")
        time.sleep(0.1)
    pyautogui.press("enter")
    time.sleep(2)

    # 4. Search and Select the contact card
    pyautogui.write(contact_to_share, interval=0.05)
    time.sleep(2.5) # Wait for search results to populate

    pyautogui.press("down")
    time.sleep(0.3)
    pyautogui.press("enter") # Checks the box for the contact
    time.sleep(1)

    # 5. Final Send Sequence
    # Tab to jump from the search box to the 'Send' arrow
    # Usually 2-3 tabs are needed to reach the final green arrow
    for _ in range(3):
        pyautogui.press("tab")
        time.sleep(0.5)
        pyautogui.press("enter")
        
    pyautogui.press("tab")
    pyautogui.press("tab")
    pyautogui.press("enter")
    

    
   
    
    print(f"✅ Contact card for '{contact_to_share}' sent to {target_person}")